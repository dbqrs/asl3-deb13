window.addEventListener('DOMContentLoaded', function () {
  const hostnameFallback = 'node12345.local';
  const themeStorageKey = 'asl3-theme-preference';

  const cockpitLink = document.getElementById('cockpit-link');
  const allmon3Link = document.getElementById('allmon3-link');
  const nodeAddress = document.getElementById('node-address');
  const themeToggle = document.getElementById('theme-toggle');
  const themeToggleText = document.getElementById('theme-toggle-text');
  const htmlElement = document.documentElement;

  function getNodeAddress() {
    return window.location.hostname || hostnameFallback;
  }

  function updateNodeAddress() {
    const currentAddress = getNodeAddress();

    if (cockpitLink) {
      cockpitLink.href = `https://${currentAddress}:9090`;
      cockpitLink.target = '_blank';
      cockpitLink.rel = 'noopener noreferrer';
    }

    if (allmon3Link) {
      allmon3Link.href = `https://${currentAddress}/allmon3/`;
      allmon3Link.target = '_blank';
      allmon3Link.rel = 'noopener noreferrer';
    }

    if (nodeAddress) {
      nodeAddress.textContent = currentAddress;
    }
  }

  /* =========================================================
     THEME TOGGLE
     Change the defaultTheme value if you want light mode first.
     Available values: 'dark' or 'light'
     ========================================================= */
  const defaultTheme = 'dark';

  function applyTheme(themeName) {
    const safeTheme = themeName === 'light' ? 'light' : 'dark';
    htmlElement.setAttribute('data-theme', safeTheme);

    if (themeToggle) {
      const nextThemeName = safeTheme === 'dark' ? 'Light' : 'Dark';
      themeToggle.setAttribute('aria-pressed', String(safeTheme === 'light'));

      if (themeToggleText) {
        themeToggleText.textContent = nextThemeName;
      }
    }
  }

  const savedTheme = window.localStorage.getItem(themeStorageKey) || defaultTheme;
  applyTheme(savedTheme);

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      const currentTheme = htmlElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
      const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
      window.localStorage.setItem(themeStorageKey, nextTheme);
    });
  }

  updateNodeAddress();
});
